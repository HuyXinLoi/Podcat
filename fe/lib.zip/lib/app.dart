// import 'package:flutter/material.dart';
// import 'package:podcat/core/base/route.dart';

// class PodcastApp extends StatelessWidget {
//   const PodcastApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp.router(
//       title: 'Podcast App',
//       routerConfig: router,
//       debugShowCheckedModeBanner: false,
//     );
//   }
// }
