package com.example.podcat.dto;

import lombok.Data;

@Data
public class PlaylistRequest {
    private String name;
}
