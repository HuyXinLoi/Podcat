package com.example.podcat.dto;

import lombok.Data;

@Data
public class AddPodcastToPlaylistRequest {
    private String podcastId;
}
