package com.example.podcat.dto;

import lombok.Data;

@Data
public class CommentRequest {
    private String content;
}
