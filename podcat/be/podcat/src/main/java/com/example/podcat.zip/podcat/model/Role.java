package com.example.podcat.model;

public enum Role {
    USER,
    ADMIN
}
